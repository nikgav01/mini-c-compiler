char funB(char b, char c){
    return '1';
}

int main()
{
    
    int arr[][4] = {"hello"};
    return 0;
}