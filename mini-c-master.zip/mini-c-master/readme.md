For part1:
Place the input code in file named input.c
Run the code using the commands:
lex lexAnalyzer.l
gcc lex.yy.c -ll
./a.out

For part2:
Give input filename as command line argument
Run the code using the commands:
yacc -d syntaxAnalyzer.y
lex lexicalAnalyzer.l
gcc y.tab.c -ll -w
./a.out filename

For part3:
Give input filename as command line argument
Run the code using the commands:
yacc -d syntaxAnalyzer.y
lex lexicalAnalyzer.l
gcc y.tab.c -ll -w
./a.out filename

For part4:
Give input filename as command line argument
Run the code using the commands:
yacc -d syntaxAnalyzer.y
lex lexicalAnalyzer.l
gcc y.tab.c -ll -w
./a.out filename